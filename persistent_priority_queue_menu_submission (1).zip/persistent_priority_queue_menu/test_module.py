import os
import tempfile
import unittest

from module import PersistentPriorityQueue


class TestPersistentPriorityQueue(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.file = os.path.join(self.temp_dir.name, "queue.json")
        self.queue = PersistentPriorityQueue(self.file)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_insert_and_peek(self):
        self.queue.insert("A", "Task A", 5)
        self.queue.insert("B", "Task B", 1)
        self.assertEqual(self.queue.peek()["id"], "B")

    def test_extract_min(self):
        self.queue.insert("A", "Task A", 5)
        self.queue.insert("B", "Task B", 1)
        self.assertEqual(self.queue.extract_min()["id"], "B")

    def test_extract_max(self):
        self.queue.insert("A", "Task A", 5)
        self.queue.insert("B", "Task B", 1)
        self.assertEqual(self.queue.extract_max()["id"], "A")

    def test_update(self):
        self.queue.insert("A", "Task A", 5)
        self.queue.update("A", value="Updated", priority=1)
        self.assertEqual(self.queue.peek()["value"], "Updated")
        self.assertEqual(self.queue.peek()["priority"], 1)

    def test_delete(self):
        self.queue.insert("A", "Task A", 1)
        self.assertTrue(self.queue.delete("A"))
        self.assertTrue(self.queue.is_empty())

    def test_persistence(self):
        self.queue.insert("A", "Task A", 1)

        queue2 = PersistentPriorityQueue(self.file)

        self.assertFalse(queue2.is_empty())
        self.assertEqual(queue2.peek()["id"], "A")

    def test_empty(self):
        self.assertTrue(self.queue.is_empty())


if __name__ == "__main__":
    unittest.main()
