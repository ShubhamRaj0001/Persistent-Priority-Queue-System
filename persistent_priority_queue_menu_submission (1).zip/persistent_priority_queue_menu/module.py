"""
Persistent Priority Queue - Menu Driven Version

Python 3.10+ is recommended because the CLI uses match-case.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional


class PersistentPriorityQueue:
    """Persistent priority queue using a binary min-heap and JSON storage."""

    def __init__(self, storage_file: str = "queue_data.json") -> None:
        self.storage_file = storage_file
        self.heap: List[Dict[str, Any]] = []
        self._load()

    # ---------------- Persistence ----------------

    def _load(self) -> None:
        if not os.path.exists(self.storage_file):
            self.heap = []
            return

        try:
            with open(self.storage_file, "r", encoding="utf-8") as file:
                data = json.load(file)

            if not isinstance(data, list):
                raise ValueError("Storage file must contain a JSON list.")

            self.heap = data
            self._heapify()

        except (json.JSONDecodeError, OSError, ValueError) as exc:
            raise RuntimeError(
                f"Could not load queue data from '{self.storage_file}': {exc}"
            ) from exc

    def _save(self) -> None:
        directory = os.path.dirname(os.path.abspath(self.storage_file))
        os.makedirs(directory, exist_ok=True)

        temp_file = self.storage_file + ".tmp"

        with open(temp_file, "w", encoding="utf-8") as file:
            json.dump(self.heap, file, indent=2, ensure_ascii=False)

        os.replace(temp_file, self.storage_file)

    # ---------------- Heap helpers ----------------

    @staticmethod
    def _less(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
        if a["priority"] != b["priority"]:
            return a["priority"] < b["priority"]
        return str(a["id"]) < str(b["id"])

    def _swap(self, i: int, j: int) -> None:
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]

    def _sift_up(self, index: int) -> None:
        while index > 0:
            parent = (index - 1) // 2

            if not self._less(self.heap[index], self.heap[parent]):
                break

            self._swap(index, parent)
            index = parent

    def _sift_down(self, index: int) -> None:
        size = len(self.heap)

        while True:
            left = 2 * index + 1
            right = left + 1
            smallest = index

            if left < size and self._less(self.heap[left], self.heap[smallest]):
                smallest = left

            if right < size and self._less(self.heap[right], self.heap[smallest]):
                smallest = right

            if smallest == index:
                break

            self._swap(index, smallest)
            index = smallest

    def _heapify(self) -> None:
        for index in range(len(self.heap) // 2 - 1, -1, -1):
            self._sift_down(index)

    def _find_index(self, item_id: str) -> int:
        for index, item in enumerate(self.heap):
            if str(item["id"]) == str(item_id):
                return index
        return -1

    # ---------------- Required operations ----------------

    def insert(self, item_id: str, value: Any, priority: float) -> Dict[str, Any]:
        if self._find_index(item_id) != -1:
            raise ValueError(f"Item with ID '{item_id}' already exists.")

        item = {
            "id": str(item_id),
            "value": value,
            "priority": priority,
        }

        self.heap.append(item)
        self._sift_up(len(self.heap) - 1)
        self._save()

        return item.copy()

    def extract_min(self) -> Optional[Dict[str, Any]]:
        if self.is_empty():
            return None

        result = self.heap[0].copy()
        last = self.heap.pop()

        if self.heap:
            self.heap[0] = last
            self._sift_down(0)

        self._save()
        return result

    def extract_max(self) -> Optional[Dict[str, Any]]:
        if self.is_empty():
            return None

        first_leaf = len(self.heap) // 2
        max_index = first_leaf

        for index in range(first_leaf + 1, len(self.heap)):
            if self.heap[index]["priority"] > self.heap[max_index]["priority"]:
                max_index = index
            elif (
                self.heap[index]["priority"] == self.heap[max_index]["priority"]
                and str(self.heap[index]["id"]) > str(self.heap[max_index]["id"])
            ):
                max_index = index

        result = self.heap[max_index].copy()
        last = self.heap.pop()

        if max_index < len(self.heap):
            self.heap[max_index] = last

            parent = (max_index - 1) // 2

            if max_index > 0 and self._less(
                self.heap[max_index], self.heap[parent]
            ):
                self._sift_up(max_index)
            else:
                self._sift_down(max_index)

        self._save()
        return result

    def peek(self) -> Optional[Dict[str, Any]]:
        if self.is_empty():
            return None
        return self.heap[0].copy()

    def update(
        self,
        item_id: str,
        value: Any = None,
        priority: Optional[float] = None,
    ) -> Dict[str, Any]:
        index = self._find_index(item_id)

        if index == -1:
            raise KeyError(f"Item with ID '{item_id}' does not exist.")

        old_priority = self.heap[index]["priority"]

        if value is not None:
            self.heap[index]["value"] = value

        if priority is not None:
            self.heap[index]["priority"] = priority

        if priority is not None:
            if priority < old_priority:
                self._sift_up(index)
            elif priority > old_priority:
                self._sift_down(index)

        self._save()

        return self.heap[self._find_index(item_id)].copy()

    def delete(self, item_id: str) -> bool:
        index = self._find_index(item_id)

        if index == -1:
            return False

        last = self.heap.pop()

        if index < len(self.heap):
            self.heap[index] = last

            parent = (index - 1) // 2

            if index > 0 and self._less(
                self.heap[index], self.heap[parent]
            ):
                self._sift_up(index)
            else:
                self._sift_down(index)

        self._save()
        return True

    def is_empty(self) -> bool:
        return len(self.heap) == 0

    def all_items(self) -> List[Dict[str, Any]]:
        return sorted(
            (item.copy() for item in self.heap),
            key=lambda item: (item["priority"], str(item["id"])),
        )


# ---------------- CLI / Switch-Case Menu ----------------

def print_menu() -> None:
    print("\n" + "=" * 50)
    print("       PERSISTENT PRIORITY QUEUE")
    print("=" * 50)
    print("1. Insert")
    print("2. Extract Min")
    print("3. Extract Max")
    print("4. Peek")
    print("5. Update")
    print("6. Delete")
    print("7. Is Empty")
    print("8. Show All Items")
    print("9. Exit")
    print("=" * 50)


def read_priority(prompt: str = "Enter priority: ") -> float:
    while True:
        try:
            return float(input(prompt).strip())
        except ValueError:
            print("Invalid priority. Please enter a number.")


def display_item(item: Optional[Dict[str, Any]]) -> None:
    if item is None:
        print("Queue is empty.")
        return

    print(f"ID       : {item['id']}")
    print(f"Value    : {item['value']}")
    print(f"Priority : {item['priority']}")


def run_menu() -> None:
    queue = PersistentPriorityQueue("queue_data.json")

    while True:
        print_menu()
        choice = input("Enter your choice (1-9): ").strip()

        # Python's switch-case equivalent.
        match choice:
            case "1":
                print("\n--- INSERT ---")
                item_id = input("Enter ID: ").strip()
                value = input("Enter value/task: ").strip()
                priority = read_priority()

                try:
                    queue.insert(item_id, value, priority)
                    print("Item inserted successfully.")
                except ValueError as exc:
                    print(f"Error: {exc}")

            case "2":
                print("\n--- EXTRACT MIN ---")
                item = queue.extract_min()
                if item:
                    print("Minimum-priority item removed:")
                    display_item(item)
                else:
                    print("Queue is empty.")

            case "3":
                print("\n--- EXTRACT MAX ---")
                item = queue.extract_max()
                if item:
                    print("Maximum-priority item removed:")
                    display_item(item)
                else:
                    print("Queue is empty.")

            case "4":
                print("\n--- PEEK ---")
                item = queue.peek()
                display_item(item)

            case "5":
                print("\n--- UPDATE ---")
                item_id = input("Enter ID to update: ").strip()

                if queue._find_index(item_id) == -1:
                    print("Error: Item not found.")
                    continue

                value = input(
                    "Enter new value (press Enter to keep current): "
                ).strip()

                priority_input = input(
                    "Enter new priority (press Enter to keep current): "
                ).strip()

                priority = None
                if priority_input:
                    try:
                        priority = float(priority_input)
                    except ValueError:
                        print("Invalid priority.")
                        continue

                try:
                    updated = queue.update(
                        item_id,
                        value=value if value else None,
                        priority=priority,
                    )
                    print("Item updated successfully:")
                    display_item(updated)
                except KeyError as exc:
                    print(f"Error: {exc}")

            case "6":
                print("\n--- DELETE ---")
                item_id = input("Enter ID to delete: ").strip()

                if queue.delete(item_id):
                    print("Item deleted successfully.")
                else:
                    print("Item not found.")

            case "7":
                print("\n--- IS EMPTY ---")
                if queue.is_empty():
                    print("Yes, the queue is empty.")
                else:
                    print("No, the queue contains items.")

            case "8":
                print("\n--- ALL ITEMS ---")
                items = queue.all_items()

                if not items:
                    print("Queue is empty.")
                else:
                    print(f"{'ID':<15} {'Priority':<12} Value")
                    print("-" * 50)

                    for item in items:
                        print(
                            f"{item['id']:<15} "
                            f"{item['priority']:<12} "
                            f"{item['value']}"
                        )

            case "9":
                print("\nThank you. Queue data has been persisted.")
                break

            case _:
                print("Invalid choice. Please select 1-9.")


if __name__ == "__main__":
    run_menu()
