# Persistent Priority Queue — Menu Driven

This project implements a persistent priority queue using a binary min-heap and JSON file storage.

## Requirements

- Python 3.10 or later
- No external packages

Python 3.10+ is recommended because the interactive menu uses `match-case`, Python's switch-case style syntax.

## Run

```bash
python module.py
```

The program displays:

```text
==================================================
       PERSISTENT PRIORITY QUEUE
==================================================
1. Insert
2. Extract Min
3. Extract Max
4. Peek
5. Update
6. Delete
7. Is Empty
8. Show All Items
9. Exit
==================================================
Enter your choice (1-9):
```

You can manually select an operation and enter the required data.

## Example

Select `1`:

```text
--- INSERT ---
Enter ID: task1
Enter value/task: Fix server issue
Enter priority: 1
Item inserted successfully.
```

Select `1` again:

```text
Enter ID: task2
Enter value/task: Update documentation
Enter priority: 5
```

Then select `8` to see all items.

Select `5` to update an item:

```text
--- UPDATE ---
Enter ID to update: task2
Enter new value (press Enter to keep current): Update API documentation
Enter new priority (press Enter to keep current): 2
Item updated successfully.
```

Select `6` to delete:

```text
--- DELETE ---
Enter ID to delete: task1
Item deleted successfully.
```

Select `9` to exit.

## Persistence

The queue is stored in:

```text
queue_data.json
```

The file is created automatically. When the program starts again, previously saved items are loaded.

## Required Operations

- `insert` — adds an item
- `extract_min` — removes the smallest-priority item
- `extract_max` — removes the largest-priority item
- `peek` — displays the smallest-priority item without removing it
- `update` — changes value and/or priority
- `delete` — removes an item by ID
- `is_empty` — checks whether the queue is empty

## Data Structure

A binary min-heap is used internally.

For every parent:

```text
parent priority <= child priority
```

For an element at index `i`:

```text
parent = (i - 1) // 2
left child = 2 * i + 1
right child = 2 * i + 2
```

## Complexity

| Operation | Complexity |
|---|---:|
| Insert | O(log n) |
| Extract Min | O(log n) |
| Extract Max | O(n) |
| Peek | O(1) |
| Update | O(log n) after locating the item |
| Delete | O(n) to locate + O(log n) adjustment |
| Is Empty | O(1) |

## Why `extract_max` is O(n)

The project uses a single min-heap. The maximum element can be among the leaves, so the implementation scans the leaves to find it.

If both minimum and maximum extraction needed strict O(log n) performance, a min-max heap or two synchronized heaps could be used.

## Real-World Use Cases

1. Job/task scheduling
2. Operating system process scheduling
3. Network packet prioritization
4. Dijkstra's shortest-path algorithm
5. Event processing systems

## Interview Explanation

A simple explanation:

> "I implemented the priority queue using a binary min-heap because it gives O(log n) insertion and minimum extraction and O(1) peek. I added a unique ID to every item so that update and delete can target a specific element. I persist the heap to a JSON file after every mutating operation and load it when the application starts. For the interactive demonstration, I used Python's match-case as a switch-case style menu so every required operation can be tested manually."

## Files

```text
persistent_priority_queue/
├── module.py
└── README.md
```

`module.py` contains both the priority queue implementation and the interactive menu.
